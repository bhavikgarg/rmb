-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 26, 2016 at 06:48 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `refermyb_projectrmb`
--

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--

CREATE TABLE IF NOT EXISTS `calendar` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `startdate` varchar(50) NOT NULL,
  `enddate` varchar(50) NOT NULL,
  `email` varchar(400) NOT NULL,
  `allDay` varchar(5) NOT NULL,
  `username` varchar(400) NOT NULL,
  `date` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `calendar`
--

INSERT INTO `calendar` (`id`, `title`, `startdate`, `enddate`, `email`, `allDay`, `username`, `date`) VALUES
(18, 'Hello', '2016-03-15T00:00:00+05:30', '2016-03-15T00:00:00+05:30', 'bhavikgarg15@gmail.com', 'false', 'singh.nishtha@gmail.com', '2016-03-15T00:00:00'),
(17, 'New Event', '2016-03-09T00:00:00+05:30', '2016-03-09T00:00:00+05:30', '', 'false', 'sandeep', '2016-03-09T00:00:00'),
(16, 'Send bhavik to delhi', '2016-03-16T00:00:00+05:30', '2016-03-16T00:00:00+05:30', '', 'false', 'parvesh.notiyal@gmail.com', '2016-03-16T00:00:00'),
(13, 'New Event', '2016-03-09T00:00:00+05:30', '2016-03-09T00:00:00+05:30', '', 'false', 'bhavik', '2016-03-09T00:00:00'),
(14, 'New Event', '2016-03-16T00:00:00+05:30', '2016-03-16T00:00:00+05:30', '', 'false', 'bhavik', '2016-03-16T00:00:00'),
(15, 'demo', '2016-03-15T00:00:00+05:30', '2016-03-15T00:00:00+05:30', 'bhavikgarg15@gmail.com', 'false', 'bhavik', '2016-03-15T00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `customer_details`
--

CREATE TABLE IF NOT EXISTS `customer_details` (
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `mob` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `Company_Name` varchar(100) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `Industry` varchar(100) DEFAULT NULL,
  `user_type` int(1) DEFAULT '3',
  `Status` varchar(20) NOT NULL DEFAULT 'ACTIVE',
  UNIQUE KEY `mob` (`mob`,`email`),
  UNIQUE KEY `fname` (`fname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_details`
--

INSERT INTO `customer_details` (`fname`, `lname`, `mob`, `email`, `Company_Name`, `City`, `Industry`, `user_type`, `Status`) VALUES
('AMIT', 'PAPNEJA', '1234567890', 'amit@egcgroup.in', 'AMIT TRADER', 'DELHI', 'CONSTRUCTION', 3, 'ACTIVE'),
('parvesh', 'kumar', '21252346347', 'parvesh.notiyal@gmail.com', 'infolink', 'DELHI', 'CONSTRUCTION', 3, 'INACTIVE'),
('niranjan', 'khuswa', '4561230789', 'niranjan.singh880@gmail.com', 'n CONSTRUCTION', 'agra', 'CONSTRUCTION', 3, 'INACTIVE'),
('Shubham', 'Gupta', '7827876765', 'bhvaik@gmail.com', 'R', 'Ghaziabad', 'CONSTRUCTION', 3, 'INACTIVE'),
('NARESH', 'SHARMA', '789456123', 'Sharma.naresh2810@gmail.com ', 'ABC CONSTRUCTION', 'DELHI', 'CONSTRUCTION', 3, 'INACTIVE'),
('manoj', 'kumar', '7894561230', 'manoj.pandey57@gmail.com', 'manoj CONSTRUCTION', 'agra', 'CONSTRUCTION', 3, 'INACTIVE'),
('Nishtha', 'Singh', '9716828905', 'singh.nishtha@gmail.com', 'Demo', 'Delhi', 'CONSTRUCTION', 3, 'INACTIVE'),
('Rahul', 'Batra', '9898899888', 'rahul@egcgroup.in', 'EGC', 'delhi', 'CONSTRUCTION', 3, 'INACTIVE'),
('sandeep', 'kapoor', '9910079669', 'infolinksoftware@gmail.com', 'infolink', 'delhi', 'CONSTRUCTION', 3, 'INACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `goodies`
--

CREATE TABLE IF NOT EXISTS `goodies` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `description` varchar(400) NOT NULL,
  `validity` varchar(400) NOT NULL,
  `isUsed` varchar(400) NOT NULL,
  `sendTo` varchar(400) NOT NULL,
  `sentBy` varchar(400) NOT NULL,
  `isSeen` varchar(10) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `goodies`
--

INSERT INTO `goodies` (`id`, `description`, `validity`, `isUsed`, `sendTo`, `sentBy`, `isSeen`) VALUES
(19, 'hello', '', 'n', 'customers', 'RMB', 'n'),
(11, 'GET Rs. 400 off on all products', '', 'n', 'singh.nishtha@gmail.com', 'singh.nishtha@gmail.com', 'y'),
(20, 'Hello Hi', '2016-03-17', 'n', 'customers', 'RMB', 'n'),
(8, 'Get 30 % off on all brands on minimum bill of Rs. 5000', '2016-12-15', 'n', 'bhavik', 'RMB', 'y'),
(9, 'Get 30 % off on all brands on minimum bill of Rs. 5000', '2016-12-15', 'n', 'bhavik', 'sandeep', 'y'),
(12, 'Get Rs. 900 off', '2016-01-01', 'n', 'singh.nishtha@gmail.com', 'bhvaik@gmail.com', 'y'),
(13, 'Buy 1 Get 1 free', '2016-03-23', 'n', 'parvesh.notiyal@gmail.com', 'singh.nishtha@gmail.com', 'y'),
(14, 'Hello', '2017-01-01', 'n', 'rmb', 'parvesh.notiyal@gmail.com', 'y'),
(17, 'Get 87', '', 'n', 'singh.nishtha@gmail.com', 'RMB', 'y'),
(21, 'Get 3 off on pantsq', '2016-02-01', 'n', 'singh.nishtha@gmail.com', 'RMB', 'y'),
(18, 'Hello Admin', '2016-03-16', 'n', 'rmb', 'singh.nishtha@gmail.com', 'y'),
(22, 'Hello hi byr', '2016-01-01', 'n', 'Mg Road', 'RMB', 'y'),
(23, 'Get 90% off on purchase of > 1000', '2016-04-28', 'n', 'rmb', 'bhvaik@gmail.com', 'y'),
(24, 'Hello', '', 'n', 'singh.nishtha@gmail.com', 'RMB', 'y');

-- --------------------------------------------------------

--
-- Table structure for table `groupdata`
--

CREATE TABLE IF NOT EXISTS `groupdata` (
  `Group_Id` int(6) NOT NULL AUTO_INCREMENT,
  `Group_Name` varchar(100) NOT NULL,
  `Group_Type` varchar(100) NOT NULL,
  `Category_Type` varchar(100) NOT NULL,
  `Status` varchar(10) NOT NULL DEFAULT 'Active',
  `Industry` varchar(100) NOT NULL,
  `Select_Premium_Group` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Group_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `groupdata`
--

INSERT INTO `groupdata` (`Group_Id`, `Group_Name`, `Group_Type`, `Category_Type`, `Status`, `Industry`, `Select_Premium_Group`) VALUES
(1, 'Mg Road Premium', 'Premium', 'Multiple', 'Active', 'CONSTRUCTION', ''),
(3, 'Mg Road', 'Normal', 'Double', 'Active', 'CONSTRUCTION', 'Mg Road Premium'),
(4, 'KIRTI NAGAR', 'Premium', 'Double', 'Active', 'CONSTRUCTION', ''),
(5, 'aer', 'Normal', 'Single', 'Active', 'CONSTRUCTION', ''),
(6, 'sdsd', 'Normal', 'Single', 'Active', 'CONSTRUCTION', ''),
(7, 'sdsd', 'Normal', 'Single', 'Active', 'CONSTRUCTION', ''),
(8, 'aaa', 'Premium', 'Single', 'Active', 'CONSTRUCTION', ''),
(9, 'aaa', 'Premium', 'Single', 'Active', 'CONSTRUCTION', ''),
(10, 'naraina', 'Normal', 'Double', 'Active', 'CONSTRUCTION', 'Mg Road Premium'),
(11, 'Meridian Hotel', 'Premium', 'Multiple', 'Active', 'hotel', ''),
(12, 'Meridian Hotel', 'Premium', 'Multiple', 'Active', 'hotel', ''),
(13, 'Le Meridian Group', 'Premium', 'Multiple', 'Active', 'hotel', ''),
(14, 'Delhi Daredevils', 'Normal', 'Multiple', 'Active', 'CONSTRUCTION', ''),
(15, 'Demo', 'Normal', 'Single', 'Active', 'Demo', '');

-- --------------------------------------------------------

--
-- Table structure for table `grouprecord`
--

CREATE TABLE IF NOT EXISTS `grouprecord` (
  `USER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `GNAME` varchar(100) NOT NULL,
  `INDUSTRY` varchar(100) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `EMAILID` varchar(100) NOT NULL,
  `CATEGORY` varchar(100) DEFAULT NULL,
  `SUBCATEGORY` varchar(100) DEFAULT NULL,
  `STATUS` varchar(10) NOT NULL DEFAULT 'ACTIVE',
  `SUB_CATEGORY_ASSIGN` int(1) NOT NULL,
  `GROUP_ID` int(10) NOT NULL,
  `MOBILE_NO` varchar(33) NOT NULL,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `grouprecord`
--

INSERT INTO `grouprecord` (`USER_ID`, `GNAME`, `INDUSTRY`, `USERNAME`, `EMAILID`, `CATEGORY`, `SUBCATEGORY`, `STATUS`, `SUB_CATEGORY_ASSIGN`, `GROUP_ID`, `MOBILE_NO`) VALUES
(1, 'Mg Road', '', 'sandeep', 'infolinksoftware@gmail.com', 'Building Shell/Structure ', 'Real Bricks ,ArtiFicial Bricks,Steel,Construction Material,Special Materials', 'ACTIVE', 1, 3, '9910079669'),
(2, 'Mg Road', '', 'sandeep', 'infolinksoftware@gmail.com', 'Wooden Flooring ', 'Laminate Flooring,Engineered Wood Flooring,Leather Flooring ,Retro Flooring,Deck flooring', 'ACTIVE', 1, 3, '9910079669'),
(3, 'Mg Road', '', 'AMIT', 'amit@egcgroup.in', 'Building Shell/Structure ', 'Real Bricks ,ArtiFicial Bricks,Steel,Construction Material,Special Materials', 'ACTIVE', 1, 3, '1234567890'),
(4, 'Mg Road', '', 'AMIT', 'amit@egcgroup.in', 'Wooden Flooring ', 'Laminate Flooring,Engineered Wood Flooring,Leather Flooring ,Retro Flooring,Deck flooring', 'ACTIVE', 1, 3, '1234567890'),
(5, 'Mg Road', '', 'Rahul', 'rahul@egcgroup.in', 'Windows', 'Wooden Windows,UPVC Windows,Aluminium Windows,Special Windows', 'ACTIVE', 1, 3, '9898899888'),
(6, 'Mg Road', '', 'Rahul', 'rahul@egcgroup.in', 'Carpets ', 'Floor Carpets ,Runners,Carpet tiles ', 'ACTIVE', 1, 3, '9898899888'),
(7, 'KIRTI NAGAR', '', 'niranjan', 'niranjan.singh880@gmail.com', 'Modular Kitchen', 'Indian Kitchen,Itaian Kitchen,German Kitchen,Chinese Kitchen,Kitchen Accessories,Kitchen Containers ', 'ACTIVE', 1, 4, '4561230789'),
(8, 'KIRTI NAGAR', '', 'manoj', 'manoj.pandey57@gmail.com', 'Modular Kitchen', 'Indian Kitchen,Itaian Kitchen,German Kitchen,Chinese Kitchen,Kitchen Accessories,Kitchen Containers ', 'ACTIVE', 1, 4, '7894561230'),
(9, 'KIRTI NAGAR', '', 'manoj', 'manoj.pandey57@gmail.com', 'Doors', 'Wooden Doors,Steel Doors,Security Doors,Main Doors ,PVC Doors,Special Doors ,UPVC Doors ,Aluminium D', 'ACTIVE', 1, 4, '7894561230'),
(10, 'Mg Road', '', 'NARESH', 'Sharma.naresh2810@gmail.com ', 'Mirrors', 'Decorative Mirrors,Dressing Mirrors ', 'ACTIVE', 1, 3, '789456123'),
(11, 'Mg Road', '', 'parvesh', 'parvesh.notiyal@gmail.com', 'Building Shell/Structure ', 'polo', 'ACTIVE', 1, 3, '21252346347'),
(12, 'Mg Road', '', 'parvesh', 'parvesh.notiyal@gmail.com', 'Building Shell/Structure ', 'polo', 'ACTIVE', 1, 3, '21252346347'),
(14, 'Mg Road', '', 'Shubham', 'bhvaik@gmail.com', 'Windows', 'UPVC Windows', 'ACTIVE', 1, 3, '7827876765'),
(15, 'Mg Road', '', 'Nishtha', 'singh.nishtha@gmail.com', 'Windows', 'Wooden Windows,Aluminium Windows', 'ACTIVE', 1, 3, '9716828905');

-- --------------------------------------------------------

--
-- Table structure for table `happy`
--

CREATE TABLE IF NOT EXISTS `happy` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `email` text NOT NULL,
  `phone` int(20) NOT NULL,
  `website` text NOT NULL,
  `dob` date NOT NULL,
  `doa` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dob` (`dob`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `happy`
--

INSERT INTO `happy` (`id`, `name`, `address`, `email`, `phone`, `website`, `dob`, `doa`) VALUES
(36, 'john', 'delhi', 'john@gmail.com', 2147483647, '', '2000-12-12', '2000-12-12'),
(37, 'john', 'delhi', 'john@gmail.com', 2147483647, '', '2000-12-12', '2000-12-12'),
(38, 'Jony', 'mumbai', 'jony@gmail.com', 2147483647, '', '2000-12-12', '2000-12-12'),
(39, 'Jony', 'mumbai', 'jony@gmail.com', 2147483647, '', '2000-12-12', '2000-12-12'),
(40, 'user', 'mumbai', 'user@gmail.com', 2147483647, '', '2000-12-12', '2000-12-12'),
(48, 'arjun', 'saket', '222@222.com', 1234567890, 'goldsgym.com', '2016-02-19', '2016-02-19'),
(54, 'raj', 'saket', '333@222.com', 2147483647, 'olx.com', '2016-02-19', '2222-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `happy_customers`
--

CREATE TABLE IF NOT EXISTS `happy_customers` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(400) NOT NULL,
  `contact` varchar(400) NOT NULL,
  `email` varchar(400) NOT NULL,
  `address` varchar(400) NOT NULL,
  `website` varchar(400) NOT NULL,
  `dob` varchar(400) NOT NULL,
  `doa` varchar(400) NOT NULL,
  `customerOf` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `happy_customers`
--

INSERT INTO `happy_customers` (`id`, `name`, `contact`, `email`, `address`, `website`, `dob`, `doa`, `customerOf`) VALUES
(11, 'nishtha', '8802934164', 'singh.nishtha@gmail.com', '', '', '', '', 'bhavik'),
(12, 'Demo', '88', 'demo@gmail.com', 'shahdara', '', '2016-01-01', '2017-02-02', 'sandeep'),
(10, 'Jitesh', 'demo', 'shah', 'demo', 'demo', '01-09-94', '03-16-16', 'bhavik'),
(9, 'Nishtha Singh', '9716828905', 'singh.nishtha94@gmail.com', 'mayur vihar', 'www.google.com', '01-09-94', '03-16-16', 'bhavik'),
(8, 'Bhavik Garg', '8802934164', 'bhavikgarg15@gmail.com', 'shahdara', 'www.google.com', '12-15-93', '03-16-16', 'bhavik'),
(13, 'Piyush Gupta', '99999999999', 'piyush@gmail.com', 'shahdara', 'www.google.com', '2017-01-01', '2017-01-01', 'sandeep'),
(14, 'Vinita Gupta', '9716828905', 'vinita@gmail.com', 'shahdara', 'www.google.com', '2017-01-01', '2016-02-01', 'parvesh.notiyal@gmail.com'),
(15, 'demo', 'demo', 'demo', 'demo', 'm', 'm', 'm', 'singh.nishtha@gmail.com'),
(16, 'm', 'm', 'm', 'm', 'm', 'm', 'm', 'bhvaik@gmail.com'),
(17, 'Sagar', '8802934164', 'sagar@gmail.com', 'shahdara', 'www.bhavik.com', '12-15-93', '12-05-93', 'bhavik'),
(18, '', '', '', '', '', '', '', 'bhavik'),
(19, '', '', '', '', '', '', '', 'bhavik');

-- --------------------------------------------------------

--
-- Table structure for table `industry`
--

CREATE TABLE IF NOT EXISTS `industry` (
  `Industry_Id` int(11) NOT NULL AUTO_INCREMENT,
  `Industry_Name` varchar(200) NOT NULL,
  `Category` varchar(200) NOT NULL,
  `Image_Icon` varchar(200) NOT NULL,
  `Sub_Category` varchar(200) NOT NULL,
  PRIMARY KEY (`Industry_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `industry`
--

INSERT INTO `industry` (`Industry_Id`, `Industry_Name`, `Category`, `Image_Icon`, `Sub_Category`) VALUES
(1, 'CONSTRUCTION', 'Building Shell/Structure ', 'images/_567a501c9d201_BRICKS.png', 'polo'),
(2, 'CONSTRUCTION', 'Building Shell/Structure ', 'images/_567a501c9d201_BRICKS.png', 'ArtiFicial Bricks'),
(3, 'CONSTRUCTION', 'Building Shell/Structure ', 'images/_567a501c9d201_BRICKS.png', 'Steel'),
(4, 'CONSTRUCTION', 'Building Shell/Structure ', 'images/_567a501c9d201_BRICKS.png', 'Construction Material'),
(5, 'CONSTRUCTION', 'Building Shell/Structure ', 'images/_567a501c9d201_BRICKS.png', 'Special Materials'),
(6, 'CONSTRUCTION', 'Windows', 'images/_567a50794eb2c_window.jpg', 'Wooden Windows'),
(7, 'CONSTRUCTION', 'Windows', 'images/_567a50794eb2c_window.jpg', 'UPVC Windows'),
(8, 'CONSTRUCTION', 'Windows', 'images/_567a50794eb2c_window.jpg', 'Aluminium Windows'),
(9, 'CONSTRUCTION', 'Windows', 'images/_567a50794eb2c_window.jpg', 'Special Windows'),
(10, 'CONSTRUCTION', 'Doors', 'images/_567a515b71fef_door.jpg', 'Wooden Doors'),
(11, 'CONSTRUCTION', 'Doors', 'images/_567a515b71fef_door.jpg', 'Steel Doors'),
(12, 'CONSTRUCTION', 'Doors', 'images/_567a515b71fef_door.jpg', 'Security Doors'),
(13, 'CONSTRUCTION', 'Doors', 'images/_567a515b71fef_door.jpg', 'Main Doors '),
(14, 'CONSTRUCTION', 'Doors', 'images/_567a515b71fef_door.jpg', 'PVC Doors'),
(15, 'CONSTRUCTION', 'Doors', 'images/_567a515b71fef_door.jpg', 'Special Doors '),
(16, 'CONSTRUCTION', 'Doors', 'images/_567a515b71fef_door.jpg', 'UPVC Doors '),
(17, 'CONSTRUCTION', 'Doors', 'images/_567a515b71fef_door.jpg', 'Aluminium Doors'),
(18, 'CONSTRUCTION', 'Modular Kitchen', 'images/_567a5203b47c3_kitchen.jpg', 'Indian Kitchen'),
(19, 'CONSTRUCTION', 'Modular Kitchen', 'images/_567a5203b47c3_kitchen.jpg', 'Itaian Kitchen'),
(20, 'CONSTRUCTION', 'Modular Kitchen', 'images/_567a5203b47c3_kitchen.jpg', 'German Kitchen'),
(21, 'CONSTRUCTION', 'Modular Kitchen', 'images/_567a5203b47c3_kitchen.jpg', 'Chinese Kitchen'),
(22, 'CONSTRUCTION', 'Modular Kitchen', 'images/_567a5203b47c3_kitchen.jpg', 'Kitchen Accessories'),
(23, 'CONSTRUCTION', 'Modular Kitchen', 'images/_567a5203b47c3_kitchen.jpg', 'Kitchen Containers '),
(24, 'CONSTRUCTION', 'Modular Kitchen', 'images/_567a5203b47c3_kitchen.jpg', 'Kitchen Cutlery'),
(25, 'CONSTRUCTION', 'Modular Kitchen', 'images/_567a5203b47c3_kitchen.jpg', 'Kitchen Worktops '),
(26, 'CONSTRUCTION', 'Mirrors', 'images/_567a52d0b686b_mirror.jpg', 'Decorative Mirrors'),
(27, 'CONSTRUCTION', 'Mirrors', 'images/_567a52d0b686b_mirror.jpg', 'Dressing Mirrors '),
(28, 'CONSTRUCTION', 'Mirrors', 'images/_567a52d0b686b_mirror.jpg', 'Compact Mirrors'),
(29, 'CONSTRUCTION', 'Mirrors', 'images/_567a52d0b686b_mirror.jpg', 'Hand Held Mirrors'),
(30, 'CONSTRUCTION', 'Carpets ', 'images/_567a5362c682a_carpet.png', 'Floor Carpets '),
(31, 'CONSTRUCTION', 'Carpets ', 'images/_567a5362c682a_carpet.png', 'Runners'),
(32, 'CONSTRUCTION', 'Carpets ', 'images/_567a5362c682a_carpet.png', 'Carpet tiles '),
(33, 'CONSTRUCTION', 'Wooden Flooring ', 'images/_567a5412c0eaa_Wooden Flooring.png', 'Laminate Flooring'),
(34, 'CONSTRUCTION', 'Wooden Flooring ', 'images/_567a5412c0eaa_Wooden Flooring.png', 'Engineered Wood Flooring'),
(35, 'CONSTRUCTION', 'Wooden Flooring ', 'images/_567a5412c0eaa_Wooden Flooring.png', 'Leather Flooring '),
(36, 'CONSTRUCTION', 'Wooden Flooring ', 'images/_567a5412c0eaa_Wooden Flooring.png', 'Retro Flooring'),
(37, 'CONSTRUCTION', 'Wooden Flooring ', 'images/_567a5412c0eaa_Wooden Flooring.png', 'Deck flooring'),
(38, 'CONSTRUCTION', 'Ceilings ', 'images/_567a546c7b393_Ceilings.jpg', 'POP ceiling'),
(39, 'CONSTRUCTION', 'Ceilings ', 'images/_567a546c7b393_Ceilings.jpg', 'Gypsum Ceiling'),
(40, 'CONSTRUCTION', 'Ceilings ', 'images/_567a546c7b393_Ceilings.jpg', 'Wooden Ceiling'),
(41, 'polo', 'golf', 'images/_56c6c256a102f_2Il1P.jpg', 'sticks'),
(42, 'wfrwef', 'fsdfdsf', 'images/_56c6cb1394d60_2Il1P.jpg', 'aSDSAD'),
(43, 'pollo', 'golf', 'images/_56c6cb52d0d38_3a0a9af9bf11cedc87b68bb67ff5ff07.jpg', 'asd'),
(44, 'hotel', 'rooms booking', 'images/_56cd6495e0df6_images (2).jpg', 'discounts'),
(45, 'Demo', 'Demo', 'images/_56e5974071098_graphic46.png', 'Demo'),
(46, 'Demo', 'Demo', 'images/_56e5974271a3f_graphic46.png', 'Demo');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` int(1) NOT NULL COMMENT '1-admin,3-general user',
  `status` int(1) NOT NULL COMMENT '1-active, 0-inactive',
  `groupName` varchar(400) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `usertype`, `status`, `groupName`) VALUES
(39, 'sandeep', 'sandeep', 1, 1, ''),
(40, 'bhavik', 'bhavik', 3, 1, 'RKGIT');

-- --------------------------------------------------------

--
-- Table structure for table `send_message`
--

CREATE TABLE IF NOT EXISTS `send_message` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Reference` text NOT NULL,
  `Remark` text NOT NULL,
  `Category` varchar(250) NOT NULL,
  `Group_Id` varchar(250) NOT NULL,
  `Receiver_Mail_Id` varchar(250) NOT NULL,
  `User_Name` varchar(100) NOT NULL,
  `User_Address` varchar(250) DEFAULT NULL,
  `User_Phone` varchar(50) NOT NULL,
  `User_Mail` varchar(200) DEFAULT NULL,
  `Rating` varchar(2) NOT NULL,
  `sender_username` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `send_message`
--

INSERT INTO `send_message` (`id`, `Reference`, `Remark`, `Category`, `Group_Id`, `Receiver_Mail_Id`, `User_Name`, `User_Address`, `User_Phone`, `User_Mail`, `Rating`, `sender_username`) VALUES
(2, 'HI NEED CARPET', 'CALL ME', 'Carpets ', '3', '', 'SANDEEP', 'INFOLINKSOFTWARE@GMAIL.COM', '9910079669', 'INFOLINKSOFTWARE@GMAIL.COM', '', ''),
(3, 'REQUIRED BRICKS', 'REQUIRED BRICKS', 'Building Shell/Structure ', '3', '', 'A', 'A', 'A', 'A', '', ''),
(4, 'need wooden flooring', 'quote me', 'Wooden Flooring ', '3', '', 'SANDEEP', 'INFOLINKSOFTWARE@GMAIL.COM', '9910079669', 'INFOLINKSOFTWARE@GMAIL.COM', '', ''),
(5, 'testing', 'my first testing', '', '3', 'infolinksoftware@gmail.com,amit@egcgroup.in', 'manoj', 'sharma nagar', '7669916548', 'manoj.pandey57@gmail.com', '', ''),
(6, 'hiiiiiii', 'fast testing', '', '3', 'infolinksoftware@gmail.com,amit@egcgroup.in', 'aaa', 'jsdjd', 'jjj', 'pppp', '', ''),
(7, 'aaaa', 'aaa', '', '3', 'infolinksoftware@gmail.com,amit@egcgroup.in', 'aa', 'kk', '999999', 'manoj.pandey57@gmail.com', '', ''),
(8, 'aa', 'kkkk', 'Wooden Flooring ', '3', 'infolinksoftware@gmail.com,amit@egcgroup.in', 'jsjjss', 'jssjsj', '838838383', 'manoj.pandey57@gmail.com', '', ''),
(9, '', '', '', '', '', '', '', '', '', '', ''),
(10, '', '', '', '', '', '', '', '', '', '', ''),
(11, 'qqq', 'wwwwwwwwwwwwww', 'Windows', '3', 'rahul@egcgroup.in', 'tomar', 'tomar', '99999999', 'tomal@123', '2', ''),
(12, 'yyyy', 'name', 'Wooden Flooring ', '3', 'infolinksoftware@gmail.com,amit@egcgroup.in', 'manoj', 'content', '898989888', '12@123', '', ''),
(13, '', '', '', '', '', '', '', '', '', '', ''),
(14, 'hh', 'dd', 'Wooden Flooring ', '3', 'infolinksoftware@gmail.com,amit@egcgroup.in', 'hh', 'pp', '666', 'gkjn', '', ''),
(15, 'jj', 'jj', 'Building Shell/Structure ', '3', 'infolinksoftware@gmail.com,amit@egcgroup.in', 'kkk', 'ttt', 'iii', 'manoj.pandey57@gmail.com', '', ''),
(16, 'hi', 'kindly call ', 'Building Shell/Structure ', '3', 'amit@egcgroup.in', 'SANDEEP', 'INFOLINKSOFTWARE@GMAIL.COM', '9910079669', '', '', ''),
(17, 'hi ', 'looking for supply of mirror', 'Mirrors', '3', 'Sharma.naresh2810@gmail.com ', 'SANDEEP', 'INFOLINKSOFTWARE@GMAIL.COM', '9910079669', '', '', ''),
(18, 'hi ', 'im looking for buildshell ', 'Building Shell/Structure ', '3', 'amit@egcgroup.in', 'sandeep', 'naraina', '9910079669', 'infolinksoftware@gmail.com', '', ''),
(19, 'hi', 'need a call urgent', 'Wooden Flooring ', '3', 'amit@egcgroup.in', 'sandeep', 'info@1.com', '35437863', 'info@1.com', '', ''),
(52, 'das', 'das', 'Modular Kitchen', '4', 'niranjan.singh880@gmail.com', 'das', 'das', 'das', 'das', '', ''),
(54, 'hotel', 'hotel', 'Select Category', '', '', 'hotel', 'hotel', 'hotel', 'hotel', '', ''),
(55, 'sandeep', 'sandeep', 'Select Category', '4', '', 'sandeep', 'sandeep', 'sandeep', 'sandeep', '', ''),
(56, 'bbhb', 'bhb', 'Select Category', '', '', 'bhavik', 'shahdara', '8802934164', 'bhavikgarg15@gmail.com', '', ''),
(57, '', '', '-1', '3', '', '', '', '', '', '', ''),
(58, 'I need a fuck', 'Fuck', 'Windows', '3', 'bhvaik@gmail.com', 'demo', 'demo', '8802934164', 'bg151293@gmail.com', '40', ''),
(59, 'Fuck u', 'Fuck', 'Windows', '3', 'rahul@egcgroup.in', 'demo', 'demo', '9', 'bhavikgarg15@gmail.com', '', 'bhvaik@gmail.com'),
(60, 'Hello this is demo on this day', 'demo on this day', 'Windows', '3', 'singh.nishtha@gmail.com', 'kunal', 'ghaziabad', '8587951005', 'kunalthakur520@gmail.com', '50', 'singh.nishtha@gmail.com'),
(61, 'Hello I need wooden windows', 'No Remarks', 'Windows', '3', 'singh.nishtha@gmail.com', 'Mohit', 'ghaziabad', '9990387380', 'bhavikgarg15@gmail.com', '30', 'bhvaik@gmail.com'),
(62, 'I need something', 'Hello', 'Wooden', '3', 'parvesh.notiyal@gmail.com', 'bhavik', 'shahdara', '8802934164', 'bhavikgarg15@gmail.com', '25', 'bhavik'),
(64, 'I need something', 'I need ', 'Wooden Flooring ', '3', 'amit@egcgroup.in', 'bhavik', 'shahdara', '8802934164', 'bhavikgarg15@gmail.com', '', 'parvesh.notiyal@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `age` int(3) NOT NULL,
  `sex` char(8) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `students`
--


-- --------------------------------------------------------

--
-- Table structure for table `usertypye`
--

CREATE TABLE IF NOT EXISTS `usertypye` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `usertype` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `usertypye`
--

INSERT INTO `usertypye` (`id`, `usertype`) VALUES
(1, 'Super Admin'),
(2, 'Admin'),
(3, 'User');
